/*create table dummy (
a int,
b int
add_column int,
sub_column int
);*/

select * from dummy;
select count(a) from dummy;
